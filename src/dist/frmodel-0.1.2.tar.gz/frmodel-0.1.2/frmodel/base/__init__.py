from frmodel.base.consts import CONSTS

__all__ = ['CONSTS']
