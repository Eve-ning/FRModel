from frmodel.express.kmeans.kmeans_scoring import kmeans_scoring_12122020

__all__ = ['kmeans_scoring_12122020']
