from frmodel.base.D2.frame2D import Frame2D
from frmodel.base.D2.video2D import Video2D

__all__ = ['Frame2D', 'Video2D']
